from bs4 import BeautifulSoup
import requests
p=input()
params="q="+p
r= requests.get("http://www.google.com/search",params=params)
print(r.url)
soup=BeautifulSoup(r.text,"html.parser")
results=soup.find("div" ,{"id" : "res"})
links =results.findAll("div",{"class" : "s"})
for items in links:
    item_text=items.find("span",{"class" : "st"}).text
    item_links=items.find("cite").text
    if item_text and item_links:
        print(item_text)
        print(item_links)